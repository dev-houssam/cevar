/* core.c : initialisation et liberation de l'API */
#include <cevar/cevar.h>

#include "cevar_internal.h"
#include "../hal/hal_ev3.h"

static int s_initialized = 0;

int cevar_init(void)
{
    if (s_initialized)
        return 0;
    if (cevar_hal_init() != 0)
        return CEVAR_ERR_IO;
    s_initialized = 1;
    return CEVAR_OK;
}

void cevar_exit(void)
{
    if (s_initialized) {
        cevar_hal_close();
        s_initialized = 0;
    }
}

const char *cevar_version(void)
{
    return "0.3.0";
}

int cevar_is_init(void)
{
    return s_initialized;
}
