/* error.c : derniere erreur, propre a chaque tache (thread) */
#include <cevar/cevar_error.h>

#include "cevar_internal.h"

static _Thread_local int s_last_error = CEVAR_OK;

int cevar_getLastError(void)
{
    return s_last_error;
}

void cevar_setError(int err)
{
    s_last_error = err;
}
