#ifndef CEVAR_INTERNAL_H
#define CEVAR_INTERNAL_H

/* Interne a la bibliotheque : jamais inclus par le programme utilisateur. */

/** 1 si cevar_init() a ete appelee avec succes, 0 sinon. */
int cevar_is_init(void);

/** Memorise l'erreur de la tache appelante (lue par cevar_getLastError). */
void cevar_setError(int err);

#endif
