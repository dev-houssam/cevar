/*
 * task.c : module taches (etape C)
 *
 * TODO : implementer startTask, stopTask, stopAllTask, abortTimeslice,
 *        releaseCPU (prototypes dans include/cevar/cevar_task.h).
 * TODO : table des taches de taille fixe, threads POSIX, arret des taches.
 */
