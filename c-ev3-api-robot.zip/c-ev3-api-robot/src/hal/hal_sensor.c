/*
 * hal_sensor.c
 *
 * Accès aux capteurs EV3 via sysfs :
 * /sys/class/lego-sensor
 */

#include "hal_ev3.h"

#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Redéfinissable à la compilation pour les tests hôte. */
#ifndef CEVAR_SENSOR_SYSFS
#define CEVAR_SENSOR_SYSFS "/sys/class/lego-sensor"
#endif

#define ATTR_PATH_MAX (CEVAR_HAL_PATH_MAX + 32)

/* Lecture générique d'un attribut sysfs. */
static int read_attr(const char *dir, const char *attr, char *buf, size_t n) {
    char path[ATTR_PATH_MAX];
    FILE *f;
    size_t len;

    snprintf(path, sizeof(path), "%s/%s", dir, attr);

    f = fopen(path, "r");
    if (f == NULL)
        return -1;

    if (fgets(buf, (int)n, f) == NULL) {
        fclose(f);
        return -1;
    }

    fclose(f);

    len = strlen(buf);

    while (len > 0 && (buf[len - 1] == '\n' || buf[len - 1] == '\r'))
        buf[--len] = '\0';

    return 0;
}

/*
 * Recherche un capteur par son adresse.
 *
 * sensorN ne correspond pas nécessairement au numéro de port.
 * Le port 0 correspond à in1, le port 1 à in2, etc.
 */
int cevar_hal_sensor_find(int port, char *dir, size_t n) 
{
    char expected[24];
    char path[ATTR_PATH_MAX];
    char addr[64];

    struct dirent *e;
    DIR *d;

    int rc = -1;

    if (port < 0 || port > 3 || dir == NULL)
        return -1;

    snprintf(expected, sizeof(expected), "ev3-ports:in%d", port + 1);

    d = opendir(CEVAR_SENSOR_SYSFS);
    if (d == NULL)
        return -1;

    while ((e = readdir(d)) != NULL) {

        if (strncmp(e->d_name, "sensor", 6) != 0)
            continue;

        snprintf(
            path,
            sizeof(path),
            "%s/%s",
            CEVAR_SENSOR_SYSFS,
            e->d_name
        );

        if (read_attr(path, "address", addr, sizeof(addr)) == 0 &&
            strcmp(addr, expected) == 0) {

            if (strlen(path) >= n)
                break;

            strcpy(dir, path);
            rc = 0;
            break;
        }
    }

    closedir(d);

    return rc;
}

/* Lecture du nom du pilote. */
int cevar_hal_sensor_get_driver(const char *dir, char *buf,size_t n) {
    return read_attr(dir, "driver_name", buf, n);
}

/* Lecture du mode actuel. */
int cevar_hal_sensor_get_mode(const char *dir, char *buf, size_t n) {
    return read_attr(dir, "mode", buf, n);
}

/* Modification du mode du capteur. */
int cevar_hal_sensor_set_mode(const char *dir, const char *mode) 
{
    char path[ATTR_PATH_MAX];

    FILE *f;
    int rc;

    snprintf(path, sizeof(path), "%s/mode", dir);

    f = fopen(path, "w");
    if (f == NULL)
        return -1;

    rc = (fputs(mode, f) < 0) ? -1 : 0;

    if (fclose(f) != 0)
        rc = -1;

    return rc;
}

/* Lecture de value0 à value7. */
int cevar_hal_sensor_get_value(const char *dir, int index, int *value) 
{
    char attr[16];
    char buf[32];
    char *end;

    long v;

    if (index < 0 || index > 7 || value == NULL)
        return -1;

    snprintf(attr, sizeof(attr), "value%d", index);

    if (read_attr(dir, attr, buf, sizeof(buf)) != 0)
        return -1;

    v = strtol(buf, &end, 10);

    if (end == buf)
        return -1;

    *value = (int)v;

    return 0;
}