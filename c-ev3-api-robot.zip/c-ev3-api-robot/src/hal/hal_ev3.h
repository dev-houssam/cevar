#ifndef CEVAR_HAL_EV3_H
#define CEVAR_HAL_EV3_H

/*
 * Couche HAL : seule couche qui connait ev3dev-c (donc sysfs).
 * Interne a la bibliotheque. Les fonctions renvoient 0 en cas de succes,
 * -1 en cas d'echec.
 */

#include <stdint.h>
#include <stddef.h>

#define CEVAR_HAL_PATH_MAX 128

int  cevar_hal_init(void);     /* ev3_init() + detection des moteurs */
void cevar_hal_close(void);

/* ----- moteurs : port 0..3 = A..D, sn = numero interne ev3dev-c ----- */
int cevar_hal_motor_find(int port, uint8_t *sn);               /* par adresse "outA".."outD" */
int cevar_hal_motor_set_duty(uint8_t sn, int duty);            /* -100..100                  */
int cevar_hal_motor_run_direct(uint8_t sn);
int cevar_hal_motor_stop(uint8_t sn);
int cevar_hal_motor_get_position(uint8_t sn, int *degrees);
int cevar_hal_motor_set_position(uint8_t sn, int degrees);
int cevar_hal_motor_get_speed(uint8_t sn, int *counts_per_s);
int cevar_hal_motor_get_count_per_rot(uint8_t sn, int *count);


/* Ajouter les primitives cevar ici */
/* ----- Capteurs : sysfs /sys/class/lego-sensor ----- */





int cevar_hal_sensor_find(int port, char *dir, size_t n );

int cevar_hal_sensor_get_driver(const char *dir, char *buf, size_t n );

int cevar_hal_sensor_get_mode(const char *dir, char *buf, size_t n );

int cevar_hal_sensor_set_mode(const char *dir, const char *mode );

int cevar_hal_sensor_get_value(const char *dir, int index, int *value );


#endif
