/* hal_ev3.c : acces aux moteurs EV3 via ev3dev-c */
#include "hal_ev3.h"

#include <ev3.h>
#include <ev3_tacho.h>

#include <stdio.h>
#include <string.h>

int cevar_hal_init(void)
{
    if (ev3_init() < 0)
        return -1;
    if (ev3_tacho_init() < 0) {
        ev3_uninit();
        return -1;
    }
    return 0;
}

void cevar_hal_close(void)
{
    ev3_uninit();
}

/* Cherche le moteur branche sur le port (par adresse, pas par ordre de detection). */
int cevar_hal_motor_find(int port, uint8_t *sn)
{
    char name[32], expected[8];
    uint8_t i;

    if (port < 0 || port > 3 || sn == NULL)
        return -1;
    snprintf(expected, sizeof(expected), "out%c", 'A' + port);

    for (i = 0; i < TACHO_DESC__LIMIT_; ++i) {
        if (ev3_tacho[i].type_inx == TACHO_TYPE__NONE_)
            continue;
        if (ev3_tacho_port_name(i, name) != NULL && strcmp(name, expected) == 0) {
            *sn = i;
            return 0;
        }
    }
    return -1;
}

int cevar_hal_motor_set_duty(uint8_t sn, int duty)
{
    return set_tacho_duty_cycle_sp(sn, duty) > 0 ? 0 : -1;
}

int cevar_hal_motor_run_direct(uint8_t sn)
{
    return set_tacho_command_inx(sn, TACHO_RUN_DIRECT) > 0 ? 0 : -1;
}

int cevar_hal_motor_stop(uint8_t sn)
{
    return set_tacho_command_inx(sn, TACHO_STOP) > 0 ? 0 : -1;
}

int cevar_hal_motor_get_position(uint8_t sn, int *degrees)
{
    return get_tacho_position(sn, degrees) > 0 ? 0 : -1;
}

int cevar_hal_motor_set_position(uint8_t sn, int degrees)
{
    return set_tacho_position(sn, degrees) > 0 ? 0 : -1;
}

int cevar_hal_motor_get_speed(uint8_t sn, int *counts_per_s)
{
    return get_tacho_speed(sn, counts_per_s) > 0 ? 0 : -1;
}

int cevar_hal_motor_get_count_per_rot(uint8_t sn, int *count)
{
    return get_tacho_count_per_rot(sn, count) > 0 ? 0 : -1;
}
