/*
 * sensor.c
 *
 * Module capteurs de C-EV3-API-ROBOT.
 */

#include <cevar/cevar_sensor.h>

#include <pthread.h>
#include <string.h>
#include <unistd.h>

#include "../core/cevar_internal.h"
#include "../hal/hal_ev3.h"

#define SENSOR_COUNT 4
#define MODE_LEN     24

/* Temps d'attente après un changement de mode. */
#define MODE_SETTLE_US 100000

/* Identifiants des pilotes EV3. */
#define DRV_TOUCH "lego-ev3-touch"
#define DRV_COLOR "lego-ev3-color"
#define DRV_US    "lego-ev3-us"
#define DRV_GYRO  "lego-ev3-gyro"

/* État privé : un verrou et un cache par port. */
static pthread_mutex_t s_mtx[SENSOR_COUNT] = {
    PTHREAD_MUTEX_INITIALIZER,
    PTHREAD_MUTEX_INITIALIZER,
    PTHREAD_MUTEX_INITIALIZER,
    PTHREAD_MUTEX_INITIALIZER
};

static char s_dir[SENSOR_COUNT][CEVAR_HAL_PATH_MAX];
static char s_drv[SENSOR_COUNT][MODE_LEN + 8];
static char s_mode[SENSOR_COUNT][MODE_LEN];

static int s_cached[SENSOR_COUNT];
static int s_gyro_off[SENSOR_COUNT];

/* Vérification du port et de l'initialisation de CEVAR. */
static int sensor_check(tSensor p)
{
    if (p < S1 || p > S4)
        return CEVAR_ERR_PARAM;

    if (!cevar_is_init())
        return CEVAR_ERR_NOT_INIT;

    return CEVAR_OK;
}

/*
 * Verrou pris :
 * retrouve le capteur, contrôle son type et configure le mode demandé.
 */
static int sensor_setup(
    tSensor p,
    const char *driver,
    const char *mode
) {
    if (!s_cached[p]) {

        if (cevar_hal_sensor_find(
                (int)p,
                s_dir[p],
                sizeof(s_dir[p])
            ) != 0)
            return CEVAR_ERR_NOT_FOUND;

        if (cevar_hal_sensor_get_driver(
                s_dir[p],
                s_drv[p],
                sizeof(s_drv[p])
            ) != 0 ||
            cevar_hal_sensor_get_mode(
                s_dir[p],
                s_mode[p],
                sizeof(s_mode[p])
            ) != 0)
            return CEVAR_ERR_IO;

        s_cached[p] = 1;
    }

    if (strcmp(s_drv[p], driver) != 0)
        return CEVAR_ERR_TYPE;

    if (strcmp(s_mode[p], mode) != 0) {

        if (cevar_hal_sensor_set_mode(s_dir[p], mode) != 0)
            return CEVAR_ERR_IO;

        strncpy(s_mode[p], mode, sizeof(s_mode[p]) - 1);
        s_mode[p][sizeof(s_mode[p]) - 1] = '\0';

        usleep(MODE_SETTLE_US);
    }

    return CEVAR_OK;
}

/*
 * Verrou pris :
 * mémorise l'erreur et invalide le cache si nécessaire.
 */
static void sensor_finish(tSensor p, int err)
{
    if (err == CEVAR_ERR_IO || err == CEVAR_ERR_NOT_FOUND)
        s_cached[p] = 0;

    cevar_setError(err);
}

/* Lecture générique de plusieurs valeurs du capteur. */
static int sensor_read(
    tSensor p,
    const char *driver,
    const char *mode,
    int n,
    int *v
) {
    int err = sensor_check(p);
    int i;

    if (err != CEVAR_OK) {
        cevar_setError(err);
        return err;
    }

    pthread_mutex_lock(&s_mtx[p]);

    err = sensor_setup(p, driver, mode);

    for (i = 0; err == CEVAR_OK && i < n; ++i) {

        if (cevar_hal_sensor_get_value(
                s_dir[p],
                i,
                &v[i]
            ) != 0)
            err = CEVAR_ERR_IO;
    }

    sensor_finish(p, err);

    pthread_mutex_unlock(&s_mtx[p]);

    return err;
}

/* ---------------------------------------------------------
 * Touch Sensor
 * --------------------------------------------------------- */

int getTouchValue(tSensor port)
{
    int v[1] = { 0 };

    if (sensor_read(port, DRV_TOUCH, "TOUCH", 1, v) != CEVAR_OK)
        return 0;

    return v[0] != 0;
}

/* ---------------------------------------------------------
 * Color Sensor
 * --------------------------------------------------------- */

void getColorRGB(tSensor port, int *r, int *g, int *b)
{
    int v[3] = { 0, 0, 0 };
    int i;

    if (r == NULL || g == NULL || b == NULL) {
        cevar_setError(CEVAR_ERR_PARAM);
        return;
    }

    if (sensor_read(port, DRV_COLOR, "RGB-RAW", 3, v) != CEVAR_OK)
        v[0] = v[1] = v[2] = 0;

    /* Conversion de 0..1020 vers 0..255. */
    for (i = 0; i < 3; ++i) {

        v[i] /= 4;

        if (v[i] < 0)
            v[i] = 0;

        if (v[i] > 255)
            v[i] = 255;
    }

    *r = v[0];
    *g = v[1];
    *b = v[2];
}

/* ---------------------------------------------------------
 * Ultrasonic Sensor
 * --------------------------------------------------------- */

int getUSDistance(tSensor port)
{
    int v[1] = { 0 };

    if (sensor_read(port, DRV_US, "US-DIST-CM", 1, v) != CEVAR_OK)
        return 0;

    return v[0] / 10;
}

/* ---------------------------------------------------------
 * Gyro Sensor
 * --------------------------------------------------------- */

/*
 * Mode GYRO-G&A :
 * value0 = angle
 * value1 = vitesse angulaire
 *
 * La lecture de l'un ne perturbe pas l'autre.
 */

int getGyroDegrees(tSensor port)
{
    int v[2] = { 0, 0 };

    if (sensor_read(port, DRV_GYRO, "GYRO-G&A", 2, v) != CEVAR_OK)
        return 0;

    pthread_mutex_lock(&s_mtx[port]);

    v[0] -= s_gyro_off[port];

    pthread_mutex_unlock(&s_mtx[port]);

    return v[0];
}

int getGyroRate(tSensor port)
{
    int v[2] = { 0, 0 };

    if (sensor_read(port, DRV_GYRO, "GYRO-G&A", 2, v) != CEVAR_OK)
        return 0;

    return v[1];
}

/*
 * Remise à zéro logicielle :
 * l'angle courant devient la nouvelle origine.
 */
void resetGyro(tSensor port)
{
    int v[2] = { 0, 0 };

    if (sensor_read(port, DRV_GYRO, "GYRO-G&A", 2, v) != CEVAR_OK)
        return;

    pthread_mutex_lock(&s_mtx[port]);

    s_gyro_off[port] = v[0];

    pthread_mutex_unlock(&s_mtx[port]);
}