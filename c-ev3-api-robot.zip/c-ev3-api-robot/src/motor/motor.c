/* motor.c : module moteurs de C-EV3-API-ROBOT (etape A) */
#include <cevar/cevar_motor.h>

#include <pthread.h>

#include "../core/cevar_internal.h"
#include "../hal/hal_ev3.h"

#define MOTOR_COUNT 4

/* Etat prive du module : un verrou, un numero interne et un cache par moteur. */
static pthread_mutex_t s_mtx[MOTOR_COUNT] = {
    PTHREAD_MUTEX_INITIALIZER, PTHREAD_MUTEX_INITIALIZER,
    PTHREAD_MUTEX_INITIALIZER, PTHREAD_MUTEX_INITIALIZER
};
static uint8_t s_sn[MOTOR_COUNT];      /* numero interne ev3dev-c            */
static int     s_cpr[MOTOR_COUNT];     /* impulsions par tour (count_per_rot) */
static int     s_cached[MOTOR_COUNT];  /* 1 si s_sn[] / s_cpr[] sont valides  */

/* Verifie le moteur demande et l'initialisation de l'API. */
static int motor_check(tMotor m)
{
    if (m < motorA || m > motorD)
        return CEVAR_ERR_PARAM;
    if (!cevar_is_init())
        return CEVAR_ERR_NOT_INIT;
    return CEVAR_OK;
}

/* A appeler verrou pris : retrouve le moteur et memorise son numero. */
static int motor_lookup(tMotor m, uint8_t *sn)
{
    if (!s_cached[m]) {
        if (cevar_hal_motor_find((int)m, &s_sn[m]) != 0)
            return CEVAR_ERR_NOT_FOUND;
        if (cevar_hal_motor_get_count_per_rot(s_sn[m], &s_cpr[m]) != 0 || s_cpr[m] <= 0)
            return CEVAR_ERR_IO;
        s_cached[m] = 1;
    }
    *sn = s_sn[m];
    return CEVAR_OK;
}

/* A appeler verrou pris : memorise l'erreur et oublie le cache si le moteur a disparu. */
static void motor_finish(tMotor m, int err)
{
    if (err == CEVAR_ERR_IO || err == CEVAR_ERR_NOT_FOUND)
        s_cached[m] = 0;
    cevar_setError(err);
}

void setMotorSpeed(tMotor motor, int speed)
{
    uint8_t sn;
    int err = motor_check(motor);
    int e;

    if (err != CEVAR_OK) {
        cevar_setError(err);
        return;
    }
    if (speed > 100)  { speed =  100; err = CEVAR_ERR_PARAM; }
    if (speed < -100) { speed = -100; err = CEVAR_ERR_PARAM; }

    pthread_mutex_lock(&s_mtx[motor]);
    e = motor_lookup(motor, &sn);
    if (e == CEVAR_OK) {
        if (speed == 0) {
            if (cevar_hal_motor_stop(sn) != 0)
                e = CEVAR_ERR_IO;
        } else if (cevar_hal_motor_set_duty(sn, speed) != 0 ||
                   cevar_hal_motor_run_direct(sn) != 0) {
            e = CEVAR_ERR_IO;
        }
    }
    if (e != CEVAR_OK)
        err = e;
    motor_finish(motor, err);
    pthread_mutex_unlock(&s_mtx[motor]);
}

int getMotorEncoder(tMotor motor)
{
    uint8_t sn;
    int pos = 0;
    int err = motor_check(motor);

    if (err != CEVAR_OK) {
        cevar_setError(err);
        return 0;
    }
    pthread_mutex_lock(&s_mtx[motor]);
    err = motor_lookup(motor, &sn);
    if (err == CEVAR_OK && cevar_hal_motor_get_position(sn, &pos) != 0)
        err = CEVAR_ERR_IO;
    if (err != CEVAR_OK)
        pos = 0;
    motor_finish(motor, err);
    pthread_mutex_unlock(&s_mtx[motor]);
    return pos;
}

int getMotorRPM(tMotor motor)
{
    uint8_t sn;
    int speed = 0, rpm = 0;
    int err = motor_check(motor);

    if (err != CEVAR_OK) {
        cevar_setError(err);
        return 0;
    }
    pthread_mutex_lock(&s_mtx[motor]);
    err = motor_lookup(motor, &sn);
    if (err == CEVAR_OK) {
        if (cevar_hal_motor_get_speed(sn, &speed) != 0)
            err = CEVAR_ERR_IO;
        else
            rpm = speed * 60 / s_cpr[motor];   /* impulsions/s -> tours/min */
    }
    motor_finish(motor, err);
    pthread_mutex_unlock(&s_mtx[motor]);
    return rpm;
}

void resetMotorEncoder(tMotor motor)
{
    uint8_t sn;
    int err = motor_check(motor);

    if (err != CEVAR_OK) {
        cevar_setError(err);
        return;
    }
    pthread_mutex_lock(&s_mtx[motor]);
    err = motor_lookup(motor, &sn);
    if (err == CEVAR_OK && cevar_hal_motor_set_position(sn, 0) != 0)
        err = CEVAR_ERR_IO;
    motor_finish(motor, err);
    pthread_mutex_unlock(&s_mtx[motor]);
}
