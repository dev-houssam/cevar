/*
 * sync.c : module semaphores (etape C)
 *
 * TODO : implementer semaphoreInitialize, semaphoreLock, semaphoreUnlock
 *        (prototypes dans include/cevar/cevar_sync.h).
 */
