/*
 * time.c : module temps (etape C)
 *
 * TODO : implementer delay, cevar_sleep, clearTimer et cevar_sysTimeMs
 *        (prototypes dans include/cevar/cevar_time.h).
 * TODO : horloge CLOCK_MONOTONIC, origine fixee par cevar_init().
 */
