#ifndef CEVAR_SENSOR_H
#define CEVAR_SENSOR_H

#include <cevar/cevar_error.h>

/* TODO (etape B) : implementer dans src/sensor/sensor.c.
 * Les prototypes ci-dessous sont ceux prevus ; ils ne sont pas encore codes. */

/** Ports d'entree 1..4. */
typedef enum { S1 = 0, S2, S3, S4 } tSensor;

int  getTouchValue(tSensor port);                       /* 1 = appuyé, 0 = relâché */
void getColorRGB(tSensor port, int *r, int *g, int *b); /* 0..255 par composante */
int  getUSDistance(tSensor port);                       /* Centimètres (255 = hors portée) */
int  getGyroDegrees(tSensor port);                      /* Degrés depuis resetGyro */
int  getGyroRate(tSensor port);                         /* Degrés par seconde */
void resetGyro(tSensor port);                           /* Robot immobile : angle courant = 0 */

#endif
