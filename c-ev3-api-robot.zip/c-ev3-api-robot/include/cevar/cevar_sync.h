#ifndef CEVAR_SYNC_H
#define CEVAR_SYNC_H

#include <pthread.h>
#include <cevar/cevar_error.h>

/* TODO (etape C) : implementer dans src/sync/sync.c. */

/** Semaphore binaire avec proprietaire (mutex + variable de condition). */
typedef struct {
    pthread_mutex_t mtx;    /* protege l'etat interne        */
    pthread_cond_t  cond;   /* attente / reveil des taches   */
    pthread_t       owner;  /* tache detentrice              */
    int             locked; /* 0 = libre, 1 = pris           */
} TSemaphore;

/* TODO */ void semaphoreInitialize(TSemaphore *sem);
/* TODO */ void semaphoreLock(TSemaphore *sem);
/* TODO */ void semaphoreUnlock(TSemaphore *sem);

#endif
