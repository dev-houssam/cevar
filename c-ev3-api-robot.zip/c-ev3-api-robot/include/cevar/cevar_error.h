#ifndef CEVAR_ERROR_H
#define CEVAR_ERROR_H

/* Codes d'erreur communs a tous les modules. */
typedef enum {
    CEVAR_OK            =  0,
    CEVAR_ERR_PARAM     = -1,  /* port ou parametre invalide                   */
    CEVAR_ERR_NOT_FOUND = -2,  /* aucun peripherique sur ce port               */
    CEVAR_ERR_TYPE      = -3,  /* peripherique present mais de mauvais type    */
    CEVAR_ERR_IO        = -4,  /* lecture/ecriture sysfs refusee               */
    CEVAR_ERR_NOT_INIT  = -5   /* cevar_init() n'a pas ete appelee             */
} tCevarError;

/**
 * Derniere erreur de la tache (thread) appelante.
 * CEVAR_OK si le dernier appel d'une fonction de l'API a reussi.
 */
int cevar_getLastError(void);

#endif
