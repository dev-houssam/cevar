#ifndef CEVAR_MOTOR_H
#define CEVAR_MOTOR_H

#include <cevar/cevar_error.h>

/** Ports de sortie A..D. */
typedef enum { motorA = 0, motorB, motorC, motorD } tMotor;

/*
 * Toutes les fonctions sont atomiques (un verrou par moteur) et utilisables
 * depuis plusieurs taches. En cas d'echec, une fonction qui renvoie une valeur
 * renvoie 0 ; l'erreur est lisible avec cevar_getLastError().
 */

/**
 * Fait tourner un moteur.
 * @param motor  motorA..motorD
 * @param speed  puissance en %, de -100 (arriere) a +100 (avant) ; 0 = arret.
 *               Hors plage : valeur bornee a +/-100 et erreur CEVAR_ERR_PARAM.
 * L'appel ne bloque pas : le moteur continue de tourner jusqu'au prochain appel.
 */
void setMotorSpeed(tMotor motor, int speed);

/**
 * Position de l'encodeur, en degres (negative en sens inverse).
 * Elle part de la valeur qu'avait l'encodeur au branchement ; voir resetMotorEncoder().
 */
int getMotorEncoder(tMotor motor);

/** Vitesse de rotation mesuree, en tours par minute (negative en sens inverse). */
int getMotorRPM(tMotor motor);

/** Remet l'encodeur a 0 (le moteur n'est pas arrete). */
void resetMotorEncoder(tMotor motor);

#endif
