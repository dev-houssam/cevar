#ifndef CEVAR_TASK_H
#define CEVAR_TASK_H

#include <cevar/cevar_error.h>

/* TODO (etape C) : implementer dans src/task/task.c. */

/** Une tache est une fonction  void f(void). */
typedef void (*tTask)(void);

/** Alias optionnels, pour ecrire les taches et main. */
typedef void TaskVoid;
typedef int  TaskInt;

/* TODO */ void startTask(tTask task);
/* TODO */ void stopTask(tTask task);
/* TODO */ void stopAllTask(void);       /* a decider : arrete aussi le programme ? */
/* TODO */ void abortTimeslice(void);    /* ex. sched_yield()                       */
/* TODO */ void releaseCPU(void);

#endif
