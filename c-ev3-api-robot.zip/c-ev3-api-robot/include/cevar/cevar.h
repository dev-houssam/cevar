#ifndef CEVAR_H
#define CEVAR_H

/* En-tete unique a inclure :  #include <cevar/cevar.h> */

#include <stdint.h>

#include <cevar/cevar_error.h>
#include <cevar/cevar_motor.h>
#include <cevar/cevar_sensor.h>
#include <cevar/cevar_task.h>
#include <cevar/cevar_sync.h>
#include <cevar/cevar_time.h>

/** Initialise l'API (a appeler une fois, avant toute autre fonction). 0 = succes. */
int cevar_init(void);

/** Libere l'API (a appeler en fin de programme). */
void cevar_exit(void);

/** Version de la bibliotheque. */
const char *cevar_version(void);

#endif
