#ifndef CEVAR_TIME_H
#define CEVAR_TIME_H

#include <stdint.h>
#include <cevar/cevar_error.h>

/* TODO (etape C) : implementer dans src/time/time.c. */

/** Compteurs reinitialisables (a confirmer avec le client : seul nSysTime est sur le schema). */
typedef enum { T1 = 0, T2, T3, T4 } tTimer;

/* TODO */ void delay(unsigned int ms);              /* suspend la tache appelante          */
/* TODO */ void cevar_sleep(unsigned int ms);        /* "sleep" entre en conflit avec unistd.h : nom a decider */
/* TODO */ void clearTimer(tTimer timer);

/* TODO */ uint32_t cevar_sysTimeMs(void);           /* ms depuis cevar_init(), horloge monotone */
#define nSysTime cevar_sysTimeMs()                   /* usage identique a ROBOTC                 */

#endif
