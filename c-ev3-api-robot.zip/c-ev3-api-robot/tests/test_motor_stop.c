
/*
 * test_motor_stop.c
 *
 * Objectif :
 * Mesurer le comportement du moteur A après une commande d'arrêt,
 * selon un protocole comparable à celui utilisé avec ROBOTC.
 *
 * Protocole :
 *   1. Commander le moteur à une puissance définie.
 *   2. Attendre sa stabilisation.
 *   3. Lire l'encodeur et le RPM avant l'arrêt.
 *   4. Envoyer setMotorSpeed(motorA, 0).
 *   5. Enregistrer les mesures toutes les 50 ms pendant 4 secondes.
 *   6. Calculer les indicateurs d'arrêt.
 *
 * Fichier produit :
 *   motor_stop_cevar.csv
 *
 * Compilation :
 *   evec test_motor_stop.c -Iinclude build/libcevar.a \
 *       -pthread -o build/test_motor_stop
 *
 * Utilisation :
 *   ./build/test_motor_stop
 *
 * Matériel :
 *   - Moteur connecté au port A.
 *   - Moteur sans charge.
 */

#include <cevar/cevar.h>

#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

/* ------------------------------------------------------------------ */
/* Configuration                                                      */
/* ------------------------------------------------------------------ */

#define MOTOR                  motorA

#define MOTOR_POWER            30
#define STABILIZATION_MS       5000

#define SAMPLE_PERIOD_MS       50
#define MEASUREMENT_DURATION   4000

#define MAX_SAMPLES            (MEASUREMENT_DURATION / SAMPLE_PERIOD_MS)

#define OUTPUT_FILE            "motor_stop_cevar.csv"

/*
 * Critères de stabilisation :
 * - RPM nul : première mesure égale à zéro.
 * - Position stable : variation <= 1 degré sur 500 ms.
 * - Stabilisation RPM : 3 mesures consécutives avec |RPM| <= 1.
 */

#define POSITION_WINDOW        10
#define POSITION_TOLERANCE     1

#define RPM_STABLE_SAMPLES     3
#define RPM_TOLERANCE          1

/* ------------------------------------------------------------------ */
/* Gestion des interruptions                                         */
/* ------------------------------------------------------------------ */

static volatile sig_atomic_t abort_requested = 0;

static void handle_signal(int signal_number)
{
    (void)signal_number;
    abort_requested = 1;
}

/* ------------------------------------------------------------------ */
/* Horloge monotone                                                   */
/* ------------------------------------------------------------------ */

static unsigned long now_ms(void)
{
    struct timespec ts;

    clock_gettime(CLOCK_MONOTONIC, &ts);

    return (unsigned long)ts.tv_sec * 1000UL
         + (unsigned long)ts.tv_nsec / 1000000UL;
}

static void sleep_until(unsigned long target_ms)
{
    while (!abort_requested) {

        unsigned long current = now_ms();

        if (current >= target_ms)
            return;

        unsigned long remaining = target_ms - current;

        usleep((remaining > 10 ? 10 : remaining) * 1000);
    }
}

/* ------------------------------------------------------------------ */
/* Structures de données                                              */
/* ------------------------------------------------------------------ */

typedef struct {

    unsigned long elapsed_ms;

    int encoder;
    int encoder_delta;

    int rpm;

} motor_sample_t;

/* ------------------------------------------------------------------ */
/* Acquisition                                                        */
/* ------------------------------------------------------------------ */

static int acquire_samples(
    motor_sample_t samples[],
    int capacity,
    int initial_encoder,
    unsigned long start_time
)
{
    int count = 0;

    unsigned long next_sample = start_time;

    int previous_encoder = initial_encoder;

    while (
        count < capacity &&
        !abort_requested
    ) {

        next_sample += SAMPLE_PERIOD_MS;

        sleep_until(next_sample);

        if (abort_requested)
            break;

        unsigned long elapsed = now_ms() - start_time;

        int encoder = getMotorEncoder(MOTOR);
        int rpm = getMotorRPM(MOTOR);

        samples[count].elapsed_ms = elapsed;

        samples[count].encoder = encoder;

        samples[count].encoder_delta =
            encoder - previous_encoder;

        samples[count].rpm = rpm;

        previous_encoder = encoder;

        count++;
    }

    return count;
}

/* ------------------------------------------------------------------ */
/* Export CSV                                                         */
/* ------------------------------------------------------------------ */

static int export_csv(
    const char *filename,
    const motor_sample_t samples[],
    int count
)
{
    FILE *file = fopen(filename, "w");

    if (file == NULL) {

        perror("Impossible de creer le fichier CSV");

        return -1;
    }

    fprintf(
        file,
        "trial,elapsed_ms,encoder,encoder_delta,rpm\n"
    );

    for (int i = 0; i < count; i++) {

        fprintf(
            file,
            "1,%lu,%d,%d,%d\n",
            samples[i].elapsed_ms,
            samples[i].encoder,
            samples[i].encoder_delta,
            samples[i].rpm
        );
    }

    fclose(file);

    return 0;
}

/* ------------------------------------------------------------------ */
/* Analyse des mesures                                                */
/* ------------------------------------------------------------------ */

static void analyze_samples(
    const motor_sample_t samples[],
    int count,
    int initial_encoder,
    int initial_rpm
)
{
    long first_zero_ms = -1;
    long stable_rpm_ms = -1;
    long stable_position_ms = -1;

    int stable_rpm_count = 0;

    printf("\n========== RESULTATS DE L'ARRET ==========\n");

    printf("RPM avant arret       : %d\n", initial_rpm);

    printf("Encodeur avant arret  : %d\n", initial_encoder);

    for (int i = 0; i < count; i++) {

        const motor_sample_t *sample = &samples[i];

        /* Premier RPM nul */

        if (
            first_zero_ms < 0 &&
            sample->rpm == 0
        ) {

            first_zero_ms = sample->elapsed_ms;
        }

        /* Trois RPM consécutifs dans la tolérance */

        if (abs(sample->rpm) <= RPM_TOLERANCE) {

            stable_rpm_count++;

            if (
                stable_rpm_count >= RPM_STABLE_SAMPLES &&
                stable_rpm_ms < 0
            ) {

                stable_rpm_ms =
                    samples[i - RPM_STABLE_SAMPLES + 1].elapsed_ms;
            }

        } else {

            stable_rpm_count = 0;
        }

        /* Position stable sur une fenêtre de 500 ms */

        if (i >= POSITION_WINDOW) {

            int displacement =
                sample->encoder -
                samples[i - POSITION_WINDOW].encoder;

            if (
                abs(displacement) <= POSITION_TOLERANCE &&
                stable_position_ms < 0
            ) {

                stable_position_ms = sample->elapsed_ms;
            }
        }
    }

    if (first_zero_ms >= 0)
        printf("Premier RPM nul      : %ld ms\n", first_zero_ms);
    else
        printf("Premier RPM nul      : non observe\n");

    if (stable_rpm_ms >= 0)
        printf("RPM stable           : %ld ms\n", stable_rpm_ms);
    else
        printf("RPM stable           : non observe\n");

    if (stable_position_ms >= 0)
        printf("Position stable      : %ld ms\n", stable_position_ms);
    else
        printf("Position stable      : non observe\n");

    if (count > 0) {

        int final_encoder = samples[count - 1].encoder;

        printf(
            "Rotation residuelle  : %+d deg\n",
            final_encoder - initial_encoder
        );

        printf(
            "Encodeur final       : %d deg\n",
            final_encoder
        );
    }

    printf("==========================================\n");
}

/* ------------------------------------------------------------------ */
/* Programme principal                                                */
/* ------------------------------------------------------------------ */

int main(void)
{
    struct sigaction sa;

    motor_sample_t samples[MAX_SAMPLES];

    int initial_encoder;
    int initial_rpm;

    int sample_count;

    unsigned long stop_time;

    /* Configuration des signaux */

    sa.sa_handler = handle_signal;

    sigemptyset(&sa.sa_mask);

    sa.sa_flags = 0;

    sigaction(SIGINT, &sa, NULL);

    sigaction(SIGTERM, &sa, NULL);

    printf("\n");
    printf("============================================\n");
    printf("       TEST D'ARRET MOTEUR - CEVAR\n");
    printf("============================================\n");

    printf("Puissance moteur : %d %%\n", MOTOR_POWER);

    printf("Stabilisation    : %d ms\n", STABILIZATION_MS);

    printf("Periode mesure   : %d ms\n", SAMPLE_PERIOD_MS);

    printf("Duree mesure     : %d ms\n", MEASUREMENT_DURATION);

    /* Initialisation CEVAR */

    if (cevar_init() != 0) {

        fprintf(stderr, "Erreur : cevar_init() a echoue.\n");

        return 1;
    }

    printf("\nCEVAR initialise.\n");

    initial_encoder = getMotorEncoder(MOTOR);

    if (cevar_getLastError() != CEVAR_OK) {

        fprintf(stderr, "Erreur : moteur A non disponible.\n");

        cevar_exit();

        return 1;
    }

    /* Mise en rotation */

    printf("\nCommande moteur : %d %%\n", MOTOR_POWER);

    setMotorSpeed(MOTOR, MOTOR_POWER);

    if (cevar_getLastError() != CEVAR_OK) {

        fprintf(stderr, "Erreur lors du demarrage du moteur.\n");

        goto cleanup;
    }

    /* Attente de stabilisation */

    printf("Stabilisation du moteur...\n");

    unsigned long stabilization_end =
        now_ms() + STABILIZATION_MS;

    sleep_until(stabilization_end);

    if (abort_requested)
        goto cleanup;

    /* Mesures juste avant l'arrêt */

    initial_encoder = getMotorEncoder(MOTOR);

    initial_rpm = getMotorRPM(MOTOR);

    printf("\n");
    printf("Avant arret :\n");

    printf("  Encodeur : %d deg\n", initial_encoder);

    printf("  RPM      : %d\n", initial_rpm);

    /* Déclenchement de l'arrêt */

    printf("\nCommande : setMotorSpeed(MOTOR, 0)\n");

    stop_time = now_ms();

    setMotorSpeed(MOTOR, 0);

    if (cevar_getLastError() != CEVAR_OK) {

        fprintf(stderr, "Erreur lors de la commande d'arret.\n");

        goto cleanup;
    }

    /* Acquisition après arrêt */

    printf("\nAcquisition en cours...\n");

    sample_count = acquire_samples(
        samples,
        MAX_SAMPLES,
        initial_encoder,
        stop_time
    );

    printf("%d mesures enregistrees.\n", sample_count);

    /* Export des données */

    if (
        export_csv(
            OUTPUT_FILE,
            samples,
            sample_count
        ) == 0
    ) {

        printf("CSV genere : %s\n", OUTPUT_FILE);
    }

    /* Analyse */

    analyze_samples(
        samples,
        sample_count,
        initial_encoder,
        initial_rpm
    );

cleanup:

    /* Sécurité : arrêt du moteur */

    printf("\nArret de securite du moteur...\n");

    setMotorSpeed(MOTOR, 0);

    cevar_exit();

    printf("CEVAR termine.\n");

    return abort_requested ? 130 : 0;
}
