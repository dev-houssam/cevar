/*
 * observe_motor.c : observer le comportement du moteur A en fonction des commandes
 *
 * Ce n'est PAS un test PASS/FAIL : le programme commande le moteur, puis affiche
 * toutes les 250 ms ce que l'API mesure (encodeur, variation, RPM, erreur), pour
 * que tu compares ce que tu VOIS tourner avec ce que tu LIS.
 *
 * Chaque appel de l'API est reaffiche avant d'etre execute  (">>> setMotorSpeed(...)").
 *
 * Materiel : un moteur sur le port A (roue libre, sans charge). Port D vide.
 *
 * Utilisation (sur la brique) :
 *   ./observe_motor          une pause "Entree" avant chaque scenario
 *   ./observe_motor --auto   enchaine tout sans pause
 *   Ctrl+C                   arrete le moteur proprement et termine le programme
 *
 * Compilation (depuis le dossier du depot c-ev3-api-robot, apres "make lib") :
 *   evec observe_motor.c -Iinclude build/libcevar.a -pthread -o build/observe_motor
 */
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include <cevar/cevar.h>

/* ------------------------------------------------------------------ */
/* Outils d'affichage et de temps                                     */
/* ------------------------------------------------------------------ */

static volatile sig_atomic_t s_abort = 0;   /* positionne par Ctrl+C */
static int s_auto = 0;

static void on_signal(int sig) { (void)sig; s_abort = 1; }

static unsigned long now_ms(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (unsigned long)ts.tv_sec * 1000UL + (unsigned long)ts.tv_nsec / 1000000UL;
}

/* Attend jusqu'a l'instant t_abs (en ms), par petits pas pour reagir a Ctrl+C. */
static void sleep_until(unsigned long t_abs)
{
    while (!s_abort) {
        long left = (long)(t_abs - now_ms());
        if (left <= 0)
            return;
        usleep((left > 20 ? 20 : (unsigned)left) * 1000u);
    }
}

static const char *err_name(void)
{
    switch (cevar_getLastError()) {
    case CEVAR_OK:            return "OK";
    case CEVAR_ERR_PARAM:     return "ERREUR CEVAR_ERR_PARAM (-1)";
    case CEVAR_ERR_NOT_FOUND: return "ERREUR CEVAR_ERR_NOT_FOUND (-2)";
    case CEVAR_ERR_TYPE:      return "ERREUR CEVAR_ERR_TYPE (-3)";
    case CEVAR_ERR_IO:        return "ERREUR CEVAR_ERR_IO (-4)";
    case CEVAR_ERR_NOT_INIT:  return "ERREUR CEVAR_ERR_NOT_INIT (-5)";
    default:                  return "ERREUR inconnue";
    }
}

/* Reaffiche l'appel puis l'execute (fonction sans valeur de retour). */
#define CALL(stmt) do { \
    printf("  >>> %-40s", #stmt); stmt; printf(" -> %s\n", err_name()); fflush(stdout); \
} while (0)

/* Reaffiche l'appel, l'execute et affiche la valeur retournee. */
#define CALLV(expr) do { \
    int v_ = (expr); \
    printf("  >>> %-40s = %6d   -> %s\n", #expr, v_, err_name()); fflush(stdout); \
} while (0)

/* setMotorSpeed(motorA, power) avec la valeur reelle affichee. */
static void do_speed(int power)
{
    printf("\n  >>> setMotorSpeed(motorA, %d)", power);
    fflush(stdout);
    setMotorSpeed(motorA, power);
    printf("   -> %s\n", err_name());
    fflush(stdout);
}

static void section(const char *title, const char *what)
{
    printf("\n==============================================================================\n");
    printf("%s\n", title);
    printf("A observer : %s\n", what);
    printf("==============================================================================\n");
    if (!s_auto && !s_abort) {
        int c;
        printf("Appuie sur Entree pour lancer (Ctrl+C = arret) ");
        fflush(stdout);
        do {
            c = getchar();
        } while (c != '\n' && c != EOF && !s_abort);
        clearerr(stdin);
    }
}

#define SECTION(title, what) do { section(title, what); if (s_abort) goto fin; } while (0)

/* ------------------------------------------------------------------ */
/* Observation : echantillonne l'encodeur et le RPM pendant duration_ms */
/* ------------------------------------------------------------------ */

typedef struct { int moved; int rpm_avg; int rpm_min; int rpm_max; } obs_t;

static obs_t observe(unsigned duration_ms, unsigned period_ms)
{
    obs_t o = { 0, 0, 0, 0 };
    unsigned long t0 = now_ms(), next = t0, t;
    int p_start = getMotorEncoder(motorA);
    int p_prev = p_start, p = p_start, rpm;
    long sum = 0;
    int n = 0, first = 1;

    printf("  (chaque ligne : getMotorEncoder(motorA) puis getMotorRPM(motorA))\n");
    printf("  %7s | %12s | %10s | %6s | etat\n", "t (ms)", "encodeur", "variation", "RPM");

    while (!s_abort) {
        next += period_ms;
        sleep_until(next);
        if (s_abort)
            break;
        t = now_ms() - t0;
        p = getMotorEncoder(motorA);
        rpm = getMotorRPM(motorA);
        printf("  %7lu | %8d deg | %+6d deg | %6d | %s\n", t, p, p - p_prev, rpm, err_name());
        fflush(stdout);
        p_prev = p;

        if (first) { o.rpm_min = o.rpm_max = rpm; first = 0; }
        if (rpm < o.rpm_min) o.rpm_min = rpm;
        if (rpm > o.rpm_max) o.rpm_max = rpm;
        if (t >= duration_ms / 2) { sum += rpm; n++; }
        if (t >= duration_ms)
            break;
    }
    o.moved = p - p_start;
    o.rpm_avg = n ? (int)(sum / n) : 0;
    printf("  resume : deplacement = %+d deg | RPM moyen (2e moitie) = %d | RPM min/max = %d / %d\n",
           o.moved, o.rpm_avg, o.rpm_min, o.rpm_max);
    return o;
}

/* ------------------------------------------------------------------ */
/* Arret mesure : combien de temps le moteur met-il VRAIMENT a s'arreter ? */
/* ------------------------------------------------------------------ */

static void measure_stop(void)
{
    enum { N = 80, PERIOD = 50, WINDOW = 10 };      /* 80 x 50 ms = 4 s ; fenetre 500 ms */
    int pos[N];
    int i, n = 0, rpm, p_cmd, rpm_cmd;
    long t_rpm0 = -1, t_still = -1;
    unsigned long t0, next, t;

    p_cmd = getMotorEncoder(motorA);
    rpm_cmd = getMotorRPM(motorA);
    printf("\n  --- ARRET MESURE ---\n");
    printf("  Avant la commande : encodeur = %d deg, RPM = %d\n", p_cmd, rpm_cmd);

    t0 = now_ms();
    do_speed(0);
    next = t0;
    printf("  %7s | %12s | %6s\n", "t (ms)", "encodeur", "RPM");

    for (i = 0; i < N && !s_abort; i++) {
        next += PERIOD;
        sleep_until(next);
        if (s_abort)
            break;
        t = now_ms() - t0;
        pos[i] = getMotorEncoder(motorA);
        rpm = getMotorRPM(motorA);
        n = i + 1;
        if (t_rpm0 < 0 && rpm == 0)
            t_rpm0 = (long)t;
        if (t_still < 0 && i >= WINDOW && abs(pos[i] - pos[i - WINDOW]) <= 1)
            t_still = (long)t;
        if (i % 4 == 3) {                          /* une ligne toutes les 200 ms */
            printf("  %7lu | %8d deg | %6d\n", t, pos[i], rpm);
            fflush(stdout);
        }
    }
    if (n == 0)
        return;

    printf("  Resultat de l'arret (commande setMotorSpeed(motorA, 0)) :\n");
    if (t_rpm0 >= 0)
        printf("    - RPM lu a 0 pour la 1re fois apres : %ld ms\n", t_rpm0);
    else
        printf("    - RPM jamais a 0 pendant 4 s\n");
    if (t_still >= 0)
        printf("    - position figee (variation <= 1 deg sur 500 ms) apres : %ld ms\n", t_still);
    else
        printf("    - position jamais figee pendant 4 s (le moteur bouge encore)\n");
    printf("    - rotation encore effectuee apres la commande : %+d deg\n", pos[n - 1] - p_cmd);
}

/* ------------------------------------------------------------------ */

int main(int argc, char **argv)
{
    struct sigaction sa;
    int i, k;
    int pw[10], avg[10], moved[10];
    obs_t o;

    for (i = 1; i < argc; i++)
        if (strcmp(argv[i], "--auto") == 0)
            s_auto = 1;

    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = on_signal;           /* sans SA_RESTART : getchar() est interrompu */
    sigemptyset(&sa.sa_mask);
    sigaction(SIGINT, &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);

    printf("Observation du moteur A -- C-EV3-API-ROBOT %s\n", cevar_version());
    printf("Mode : %s. Ctrl+C arrete le moteur et termine le programme.\n",
           s_auto ? "automatique (sans pause)" : "une pause avant chaque scenario");

    if (cevar_init() != 0) {
        fprintf(stderr, "Erreur : cevar_init() a echoue\n");
        return 1;
    }
    printf("\n  >>> cevar_init() -> OK\n");
    CALLV(getMotorEncoder(motorA));
    if (cevar_getLastError() != CEVAR_OK) {
        fprintf(stderr, "Erreur : aucun moteur detecte sur le port A\n");
        cevar_exit();
        return 1;
    }

    /* ---- 1 ---- */
    SECTION("1/9  Etat initial, moteur NON commande",
            "encodeur et RPM sans aucune commande. Pendant 6 s, TOURNE L'AXE A LA MAIN "
            "dans les deux sens : l'encodeur doit changer et le RPM suivre le sens.");
    CALLV(getMotorEncoder(motorA));
    CALLV(getMotorRPM(motorA));
    observe(6000, 250);

    /* ---- 2 ---- */
    SECTION("2/9  Paliers positifs : +30, +50, +100 (5 s chacun, sans arret entre les paliers)",
            "la vitesse percue augmente avec la puissance ; le RPM mesure suit ; l'encodeur augmente. "
            "Regarde le temps de montee en vitesse apres chaque changement.");
    do_speed(30);  observe(5000, 250);
    do_speed(50);  observe(5000, 250);
    do_speed(100); observe(5000, 250);
    measure_stop();

    /* ---- 3 ---- */
    SECTION("3/9  Paliers negatifs : -30, -50, -100 (5 s chacun)",
            "meme chose en sens inverse : l'encodeur DIMINUE, le RPM est NEGATIF.");
    do_speed(-30);  observe(5000, 250);
    do_speed(-50);  observe(5000, 250);
    do_speed(-100); observe(5000, 250);
    measure_stop();

    /* ---- 4 ---- */
    SECTION("4/9  Inversion directe : +60 puis -60 SANS passer par 0",
            "le moteur freine puis repart dans l'autre sens : le RPM passe par 0 puis devient "
            "negatif ; l'encodeur monte, s'arrete, puis redescend.");
    do_speed(60);  observe(4000, 250);
    do_speed(-60); observe(5000, 250);
    measure_stop();

    /* ---- 5 ---- */
    SECTION("5/9  resetMotorEncoder() PENDANT que le moteur tourne",
            "l'encodeur retombe a ~0 d'un coup, mais le moteur ne s'arrete pas et l'encodeur "
            "continue de compter a partir de 0.");
    do_speed(50);
    observe(3000, 250);
    printf("\n");
    CALL(resetMotorEncoder(motorA));
    observe(4000, 250);
    measure_stop();

    /* ---- 6 ---- */
    SECTION("6/9  resetMotorEncoder() moteur a l'arret",
            "avant/apres le reset : valeur lue puis 0 ; pendant 4 s la valeur reste 0 "
            "(tourne l'axe a la main pour la voir changer).");
    CALLV(getMotorEncoder(motorA));
    CALL(resetMotorEncoder(motorA));
    CALLV(getMotorEncoder(motorA));
    observe(4000, 500);

    /* ---- 7 ---- */
    SECTION("7/9  Vitesses hors plage : +150 puis -150",
            "l'API borne a +100 / -100 ET signale CEVAR_ERR_PARAM : le moteur tourne comme a "
            "100 % (compare le RPM avec le palier +100 / -100 vus plus haut).");
    do_speed(150);  observe(4000, 250);
    do_speed(-150); observe(4000, 250);
    measure_stop();

    /* ---- 8 ---- */
    SECTION("8/9  Rampe de puissance 10 % -> 100 % (3 s par palier), depuis l'arret",
            "a partir de quelle puissance le moteur demarre-t-il ? Le RPM est-il proportionnel "
            "a la puissance ? Le tableau final resume la rampe.");
    for (k = 0; k < 10 && !s_abort; k++) {
        pw[k] = (k + 1) * 10;
        do_speed(pw[k]);
        o = observe(3000, 500);
        avg[k] = o.rpm_avg;
        moved[k] = o.moved;
    }
    if (!s_abort) {
        printf("\n  Tableau de la rampe :\n");
        printf("  %10s | %10s | %18s | %10s\n", "puissance", "RPM moyen", "deplacement en 3 s", "deg/s");
        for (k = 0; k < 10; k++)
            printf("  %9d%% | %10d | %14d deg | %10d\n", pw[k], avg[k], moved[k], moved[k] / 3);
    }
    measure_stop();

    /* ---- 9 ---- */
    SECTION("9/9  Appels invalides et port vide (le moteur A ne doit pas bouger)",
            "chaque appel est reaffiche avec la valeur retournee et le code d'erreur. "
            "ATTENTION : si un moteur est branche sur le port D, il tournera.");
    CALL(setMotorSpeed((tMotor)7, 50));
    CALLV(getMotorEncoder((tMotor)7));
    CALLV(getMotorRPM((tMotor)7));
    CALL(resetMotorEncoder((tMotor)7));
    CALLV(getMotorEncoder(motorD));
    CALLV(getMotorRPM(motorD));
    CALL(resetMotorEncoder(motorD));
    CALL(setMotorSpeed(motorD, 50));
    CALL(setMotorSpeed(motorD, 0));
    observe(3000, 500);

fin:
    printf("\n==============================================================================\n");
    printf("%s\n", s_abort ? "Interrompu : arret des moteurs." : "Fin des scenarios : arret des moteurs.");
    CALL(setMotorSpeed(motorA, 0));
    printf("  (arret du port D par securite : NOT_FOUND est normal si D est vide)\n");
    CALL(setMotorSpeed(motorD, 0));
    printf("  >>> cevar_exit()\n");
    cevar_exit();
    return 0;
}
