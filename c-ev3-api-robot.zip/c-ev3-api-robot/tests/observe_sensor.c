
/*
 * observe_sensor.c : observer le comportement des capteurs EV3
 *
 * Ce programme n'est PAS un test PASS/FAIL.
 * Il affiche les valeurs mesurees par les primitives CEVAR afin de
 * comparer les manipulations physiques avec les valeurs retournees.
 *
 * Chaque appel de l'API est affiche avant son execution.
 *
 * Chaque scenario d'observation dure 40 secondes.
 *
 * Configuration materielle par defaut :
 *   Touch Sensor      : S1
 *   Color Sensor      : S2
 *   Ultrasonic Sensor : S3
 *   Gyro Sensor       : S4
 *
 * Utilisation :
 *   ./observe_sensor          pause Entree avant chaque scenario
 *   ./observe_sensor --auto   enchaine sans pause
 *   Ctrl+C                    termine proprement le programme
 *
 * Compilation :
 *   make lib
 *   evec tests/observe_sensor.c -Iinclude build/libcevar.a \
 *       -pthread -o build/observe_sensor
 */

#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include <cevar/cevar.h>
#include <cevar/cevar_sensor.h>

/* ------------------------------------------------------------------ */
/* Configuration des ports                                            */
/* ------------------------------------------------------------------ */

#define TOUCH_PORT S1
#define COLOR_PORT S2
#define US_PORT    S3
#define GYRO_PORT  S4

#define OBS_DURATION_MS 40000
#define OBS_PERIOD_MS     250

/* ------------------------------------------------------------------ */
/* Outils d'affichage et de temps                                      */
/* ------------------------------------------------------------------ */

static volatile sig_atomic_t s_abort = 0;
static int s_auto = 0;

static void on_signal(int sig)
{
    (void)sig;
    s_abort = 1;
}

static unsigned long now_ms(void)
{
    struct timespec ts;

    clock_gettime(CLOCK_MONOTONIC, &ts);

    return (unsigned long)ts.tv_sec * 1000UL
         + (unsigned long)ts.tv_nsec / 1000000UL;
}

/* Attend jusqu'a l'instant t_abs, par petits pas pour reagir a Ctrl+C. */
static void sleep_until(unsigned long t_abs)
{
    while (!s_abort) {
        unsigned long now = now_ms();
        unsigned long left;

        if (now >= t_abs)
            return;

        left = t_abs - now;

        usleep((left > 20 ? 20 : left) * 1000u);
    }
}

static const char *err_name(void)
{
    switch (cevar_getLastError()) {
    case CEVAR_OK:
        return "OK";

    case CEVAR_ERR_PARAM:
        return "ERREUR CEVAR_ERR_PARAM (-1)";

    case CEVAR_ERR_NOT_FOUND:
        return "ERREUR CEVAR_ERR_NOT_FOUND (-2)";

    case CEVAR_ERR_TYPE:
        return "ERREUR CEVAR_ERR_TYPE (-3)";

    case CEVAR_ERR_IO:
        return "ERREUR CEVAR_ERR_IO (-4)";

    case CEVAR_ERR_NOT_INIT:
        return "ERREUR CEVAR_ERR_NOT_INIT (-5)";

    default:
        return "ERREUR inconnue";
    }
}

/* Reaffiche un appel sans valeur de retour. */
#define CALL(stmt) do {                                      \
    printf("  >>> %-42s", #stmt);                            \
    fflush(stdout);                                          \
    stmt;                                                    \
    printf(" -> %s\n", err_name());                          \
    fflush(stdout);                                          \
} while (0)

/* Reaffiche un appel et sa valeur de retour. */
#define CALLV(expr) do {                                     \
    int v_ = (expr);                                         \
    printf("  >>> %-42s = %6d -> %s\n",                      \
           #expr, v_, err_name());                           \
    fflush(stdout);                                          \
} while (0)

/* ------------------------------------------------------------------ */
/* Gestion des scenarios                                              */
/* ------------------------------------------------------------------ */

static void section(const char *title, const char *what)
{
    printf("\n");
    printf("==============================================================================\n");
    printf("%s\n", title);
    printf("A observer : %s\n", what);
    printf("Duree : 40 secondes\n");
    printf("==============================================================================\n");

    if (!s_auto && !s_abort) {
        int c;

        printf("Appuie sur Entree pour lancer (Ctrl+C = arret) ");
        fflush(stdout);

        do {
            c = getchar();
        } while (c != '\n' && c != EOF && !s_abort);

        clearerr(stdin);
    }
}

#define SECTION(title, what) do { \
    section(title, what);         \
    if (s_abort) goto fin;        \
} while (0)

/* ------------------------------------------------------------------ */
/* 1. Touch Sensor                                                    */
/* ------------------------------------------------------------------ */

static void observe_touch(void)
{
    unsigned long t0 = now_ms();
    unsigned long next = t0;
    unsigned long t;

    int value;

    printf("\n");
    printf("  Appuie et relache plusieurs fois le bouton tactile.\n");
    printf("  %7s | %12s | %s\n", "t (ms)", "valeur", "etat");

    while (!s_abort) {
        next += OBS_PERIOD_MS;
        sleep_until(next);

        if (s_abort)
            break;

        t = now_ms() - t0;

        value = getTouchValue(TOUCH_PORT);

        printf("  %7lu | %12d | %s | %s\n",
               t,
               value,
               value ? "APPUYE" : "RELACHE",
               err_name());

        fflush(stdout);

        if (t >= OBS_DURATION_MS)
            break;
    }
}

/* ------------------------------------------------------------------ */
/* 2. Color Sensor                                                    */
/* ------------------------------------------------------------------ */

static void observe_color(void)
{
    unsigned long t0 = now_ms();
    unsigned long next = t0;
    unsigned long t;

    int r, g, b;

    printf("\n");
    printf("  Place differents objets devant le capteur.\n");
    printf("  %7s | %6s | %6s | %6s | %s\n",
           "t (ms)", "RED", "GREEN", "BLUE", "etat");

    while (!s_abort) {
        next += OBS_PERIOD_MS;
        sleep_until(next);

        if (s_abort)
            break;

        t = now_ms() - t0;

        r = 0;
        g = 0;
        b = 0;

        getColorRGB(COLOR_PORT, &r, &g, &b);

        printf("  %7lu | %6d | %6d | %6d | %s\n",
               t, r, g, b, err_name());

        fflush(stdout);

        if (t >= OBS_DURATION_MS)
            break;
    }
}

/* ------------------------------------------------------------------ */
/* 3. Ultrasonic Sensor                                                */
/* ------------------------------------------------------------------ */

static void observe_ultrasonic(void)
{
    unsigned long t0 = now_ms();
    unsigned long next = t0;
    unsigned long t;

    int distance;

    printf("\n");
    printf("  Deplace un obstacle devant le capteur ultrason.\n");
    printf("  %7s | %12s | %s\n",
           "t (ms)", "distance", "etat");

    while (!s_abort) {
        next += OBS_PERIOD_MS;
        sleep_until(next);

        if (s_abort)
            break;

        t = now_ms() - t0;

        distance = getUSDistance(US_PORT);

        printf("  %7lu | %9d cm | %s\n",
               t, distance, err_name());

        fflush(stdout);

        if (t >= OBS_DURATION_MS)
            break;
    }
}

/* ------------------------------------------------------------------ */
/* 4. Gyroscope : angle et vitesse angulaire                           */
/* ------------------------------------------------------------------ */

static void observe_gyro(void)
{
    unsigned long t0 = now_ms();
    unsigned long next = t0;
    unsigned long t;

    int degrees;
    int rate;

    printf("\n");
    printf("  Fais tourner le robot sur lui-meme, puis immobilise-le.\n");
    printf("  %7s | %12s | %12s | %s\n",
           "t (ms)", "angle (deg)", "vitesse", "etat");

    while (!s_abort) {
        next += OBS_PERIOD_MS;
        sleep_until(next);

        if (s_abort)
            break;

        t = now_ms() - t0;

        degrees = getGyroDegrees(GYRO_PORT);
        rate = getGyroRate(GYRO_PORT);

        printf("  %7lu | %12d | %9d deg/s | %s\n",
               t, degrees, rate, err_name());

        fflush(stdout);

        if (t >= OBS_DURATION_MS)
            break;
    }
}

/* ------------------------------------------------------------------ */
/* 5. Gyroscope : reset                                                */
/* ------------------------------------------------------------------ */

static void test_gyro_reset(void)
{
    int before;
    int after;

    printf("\n  Le robot doit etre immobile pour ce scenario.\n\n");

    before = getGyroDegrees(GYRO_PORT);

    printf("  >>> getGyroDegrees(GYRO_PORT) = %d -> %s\n",
           before, err_name());

    CALL(resetGyro(GYRO_PORT));

    after = getGyroDegrees(GYRO_PORT);

    printf("  >>> getGyroDegrees(GYRO_PORT) = %d -> %s\n",
           after, err_name());

    printf("\n  Observation : l'angle apres reset doit etre proche de 0.\n");
    printf("  Une nouvelle observation de 40 secondes commence.\n");

    observe_gyro();
}

/* ------------------------------------------------------------------ */
/* 6. Appels invalides et mauvais types                                */
/* ------------------------------------------------------------------ */

static void test_invalid(void)
{
    int r = -1;
    int g = -1;
    int b = -1;

    printf("\n  Ces appels ne doivent pas declencher de mesure valide.\n");

    printf("\n  --- Port invalide ---\n");

    CALLV(getTouchValue((tSensor)7));

    CALLV(getUSDistance((tSensor)7));

    CALLV(getGyroDegrees((tSensor)7));

    CALLV(getGyroRate((tSensor)7));

    CALL(resetGyro((tSensor)7));

    CALL(getColorRGB((tSensor)7, &r, &g, &b));

    printf("\n  RGB apres appel invalide : R=%d G=%d B=%d\n",
           r, g, b);

    printf("\n  --- Mauvais type de capteur ---\n");

    printf("  Exemple : appeler getUSDistance() sur le port du Touch Sensor.\n");

    CALLV(getUSDistance(TOUCH_PORT));

    printf("\n  Les erreurs attendues sont CEVAR_ERR_PARAM ou CEVAR_ERR_TYPE.\n");
}

/* ------------------------------------------------------------------ */
/* Programme principal                                                */
/* ------------------------------------------------------------------ */

int main(int argc, char **argv)
{
    struct sigaction sa;
    int i;

    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--auto") == 0)
            s_auto = 1;
    }

    memset(&sa, 0, sizeof(sa));

    sa.sa_handler = on_signal;

    sigemptyset(&sa.sa_mask);

    sigaction(SIGINT, &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);

    printf("Observation des capteurs EV3 -- C-EV3-API-ROBOT %s\n",
           cevar_version());

    printf("Mode : %s\n",
           s_auto ? "automatique (sans pause)" : "pause avant chaque scenario");

    printf("Duree de chaque observation : 40 secondes\n");

    printf("\nConfiguration des ports :\n");
    printf("  Touch Sensor      : S1\n");
    printf("  Color Sensor      : S2\n");
    printf("  Ultrasonic Sensor : S3\n");
    printf("  Gyro Sensor       : S4\n");

    if (cevar_init() != 0) {
        fprintf(stderr, "\nErreur : cevar_init() a echoue\n");
        return 1;
    }

    printf("\n  >>> cevar_init() -> OK\n");

    /* ---- 1 ---- */

    SECTION("1/6  Touch Sensor : lecture de l'etat du bouton",
            "appuie et relache le bouton tactile. La valeur doit passer de 0 a 1.");

    CALLV(getTouchValue(TOUCH_PORT));

    observe_touch();

    /* ---- 2 ---- */

    SECTION("2/6  Color Sensor : lecture des composantes RGB",
            "place plusieurs objets de couleurs differentes devant le capteur. "
            "Observe les variations des composantes rouge, verte et bleue.");

    CALL(getColorRGB(COLOR_PORT, &(int){0}, &(int){0}, &(int){0}));

    observe_color();

    /* ---- 3 ---- */

    SECTION("3/6  Ultrasonic Sensor : mesure de distance",
            "approche et eloigne un obstacle. La distance doit evoluer en fonction "
            "de sa position devant le capteur.");

    CALLV(getUSDistance(US_PORT));

    observe_ultrasonic();

    /* ---- 4 ---- */

    SECTION("4/6  Gyroscope : mesure de l'angle et de la vitesse",
            "fais tourner le robot sur lui-meme. Observe l'evolution de l'angle "
            "et de la vitesse angulaire.");

    CALLV(getGyroDegrees(GYRO_PORT));
    CALLV(getGyroRate(GYRO_PORT));

    observe_gyro();

    /* ---- 5 ---- */

    SECTION("5/6  Gyroscope : reinitialisation de l'angle",
            "l'angle courant devient la nouvelle origine. Le robot doit rester immobile.");

    test_gyro_reset();

    /* ---- 6 ---- */

    SECTION("6/6  Appels invalides et verification des types",
            "teste les ports invalides et un mauvais type de capteur.");

    test_invalid();

fin:

    printf("\n");
    printf("==============================================================================\n");
    printf("%s\n",
           s_abort ? "Programme interrompu." : "Fin des observations.");

    printf("  >>> cevar_exit()\n");

    cevar_exit();

    printf("==============================================================================\n");

    return 0;
}
