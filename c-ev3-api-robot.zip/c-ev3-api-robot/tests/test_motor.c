/*
 * test_motor.c : validation du module moteurs SUR LA BRIQUE
 *
 * Materiel : un moteur sur le port A (roue libre, sans charge), le port D vide.
 * Methode  : boite noire. On appelle l'API publique et on verifie son effet
 *            avec l'encodeur et le RPM mesures par l'API elle-meme.
 * Sortie   : PASS / FAIL par cas ; code de retour = nombre d'echecs.
 *
 * Les tolerances (cas 2, 4, 5) sont des valeurs de depart, a ajuster apres
 * les premieres mesures sur la brique.
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <cevar/cevar.h>

static int s_fail = 0;

#define CHECK(name, cond) do { \
    if (cond) printf("PASS  %s\n", (name)); \
    else { printf("FAIL  %s\n", (name)); s_fail++; } } while (0)

/* delay() arrivera a l'etape C : en attendant, une pause locale. */
static void wait_ms(unsigned ms) { usleep(ms * 1000u); }

int main(void)
{
    int p0, p1, p2, rpm, est, tol;

    printf("== Validation du module moteurs (moteur sur le port A) ==\n");

    /* Cas 0 : appels AVANT cevar_init() -> NOT_INIT, aucun effet */
    setMotorSpeed(motorA, 50);
    CHECK("0a avant init : setMotorSpeed -> NOT_INIT", cevar_getLastError() == CEVAR_ERR_NOT_INIT);
    getMotorEncoder(motorA);
    CHECK("0b avant init : getMotorEncoder -> NOT_INIT", cevar_getLastError() == CEVAR_ERR_NOT_INIT);
    getMotorRPM(motorA);
    CHECK("0c avant init : getMotorRPM -> NOT_INIT", cevar_getLastError() == CEVAR_ERR_NOT_INIT);
    resetMotorEncoder(motorA);
    CHECK("0d avant init : resetMotorEncoder -> NOT_INIT", cevar_getLastError() == CEVAR_ERR_NOT_INIT);

    if (cevar_init() != 0) {
        fprintf(stderr, "Erreur : cevar_init() a echoue\n");
        return 1;
    }
    getMotorEncoder(motorA);
    if (cevar_getLastError() != CEVAR_OK) {
        fprintf(stderr, "Erreur : aucun moteur detecte sur le port A\n");
        cevar_exit();
        return 1;
    }

    /* Cas 1 : +50 -> l'encodeur augmente, le RPM est positif */
    p0 = getMotorEncoder(motorA);
    setMotorSpeed(motorA, 50);
    wait_ms(800);
    p1 = getMotorEncoder(motorA);
    rpm = getMotorRPM(motorA);
    CHECK("1a +50 : l'encodeur augmente", p1 - p0 > 20);
    CHECK("1b +50 : RPM positif", rpm > 0);
    CHECK("1c +50 : aucune erreur", cevar_getLastError() == CEVAR_OK);

    /* Cas 2 : coherence RPM / encodeur (moyenne sur 1 s, moteur en regime) */
    p0 = getMotorEncoder(motorA);
    wait_ms(1000);
    p1 = getMotorEncoder(motorA);
    rpm = getMotorRPM(motorA);
    est = (p1 - p0) / 6;                  /* degres/s -> tr/min : /360*60 */
    tol = est / 5 > 10 ? est / 5 : 10;    /* 20 % ou 10 tr/min            */
    CHECK("2  RPM coherent avec l'encodeur", abs(rpm - est) <= tol);

    /* Cas 3 : -50 -> l'encodeur diminue, le RPM est negatif */
    p0 = getMotorEncoder(motorA);
    setMotorSpeed(motorA, -50);
    wait_ms(800);
    p1 = getMotorEncoder(motorA);
    rpm = getMotorRPM(motorA);
    CHECK("3a -50 : l'encodeur diminue", p1 - p0 < -20);
    CHECK("3b -50 : RPM negatif", rpm < 0);

    /* Cas 4 : 0 -> le moteur s'arrete (position stable, RPM nul) */
    setMotorSpeed(motorA, 0);
    wait_ms(800);
    p1 = getMotorEncoder(motorA);
    wait_ms(300);
    p2 = getMotorEncoder(motorA);
    rpm = getMotorRPM(motorA);
    CHECK("4a 0 : position stable", p2 - p1 >= -2 && p2 - p1 <= 2);
    CHECK("4b 0 : RPM nul", rpm == 0);

    /* Cas 5 : resetMotorEncoder remet l'encodeur a 0 */
    resetMotorEncoder(motorA);
    p1 = getMotorEncoder(motorA);
    CHECK("5a reset : encodeur ~ 0", p1 >= -2 && p1 <= 2);
    setMotorSpeed(motorA, 50);
    wait_ms(500);
    p1 = getMotorEncoder(motorA);
    CHECK("5b reset puis +50 : l'encodeur repart de 0 (positif)", p1 > 0);
    setMotorSpeed(motorA, 0);
    wait_ms(500);

    /* Cas 6 : vitesse hors plage -> bornee a 100 ET erreur signalee */
    setMotorSpeed(motorA, 150);
    CHECK("6a 150 : CEVAR_ERR_PARAM", cevar_getLastError() == CEVAR_ERR_PARAM);
    wait_ms(500);
    rpm = getMotorRPM(motorA);
    CHECK("6b 150 : le moteur tourne (borne a 100)", rpm > 0);
    setMotorSpeed(motorA, 0);
    wait_ms(500);

    /* Cas 7 : moteur invalide */
    setMotorSpeed((tMotor)7, 50);
    CHECK("7a moteur invalide : setMotorSpeed -> PARAM", cevar_getLastError() == CEVAR_ERR_PARAM);
    p1 = getMotorEncoder((tMotor)7);
    CHECK("7b moteur invalide : getMotorEncoder -> 0 et PARAM",
          p1 == 0 && cevar_getLastError() == CEVAR_ERR_PARAM);

    /* Cas 8 : port D sans moteur -> NOT_FOUND (ignore si un moteur y est branche) */
    getMotorEncoder(motorD);
    if (cevar_getLastError() == CEVAR_ERR_NOT_FOUND) {
        CHECK("8a port D vide : getMotorEncoder -> 0 et NOT_FOUND",
              getMotorEncoder(motorD) == 0 && cevar_getLastError() == CEVAR_ERR_NOT_FOUND);
        CHECK("8b port D vide : getMotorRPM -> 0 et NOT_FOUND",
              getMotorRPM(motorD) == 0 && cevar_getLastError() == CEVAR_ERR_NOT_FOUND);
        setMotorSpeed(motorD, 50);
        CHECK("8c port D vide : setMotorSpeed -> NOT_FOUND", cevar_getLastError() == CEVAR_ERR_NOT_FOUND);
    } else {
        printf("SKIP  8  un moteur est branche sur le port D\n");
    }

    setMotorSpeed(motorA, 0);
    cevar_exit();

    printf("== Resultat : %s (%d echec%s) ==\n",
           s_fail == 0 ? "VALIDE" : "NON VALIDE", s_fail, s_fail > 1 ? "s" : "");
    return s_fail;
}
