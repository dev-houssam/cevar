# Module moteurs (étape A)

Fichiers : `include/cevar/cevar_motor.h`, `src/motor/motor.c`, couche `src/hal/hal_ev3.c`.

Les prototypes sont inspirés de ROBOTC. Le comportement décrit ici est celui de CEVAR et fait foi.

## Généralités

| Point | Comportement |
|---|---|
| Moteurs | `motorA`, `motorB`, `motorC`, `motorD` (ports de sortie A à D) |
| Détection | Le moteur est retrouvé par son adresse (`outA`..`outD`), pas par l'ordre de détection ; grand ou medium, sans rien à préciser |
| Initialisation | `cevar_init()` doit avoir été appelée, sinon `CEVAR_ERR_NOT_INIT` |
| Erreurs | En cas d'échec, la fonction renvoie 0 (ou ne fait rien) ; la cause se lit avec `cevar_getLastError()` |
| Dernière erreur | Propre à chaque tâche (thread) : deux tâches ne s'écrasent pas leurs erreurs. Remise à `CEVAR_OK` à chaque appel réussi |
| Multitâche | Un verrou par moteur : chaque appel est atomique, utilisable depuis plusieurs tâches |
| Mécanisme | Écriture/lecture des attributs sysfs d'EV3Dev via ev3dev-c (mode `run-direct`) |

## setMotorSpeed

```c
void setMotorSpeed(tMotor motor, int speed);
```

Fait tourner un moteur. L'appel ne bloque pas : le moteur continue de tourner jusqu'au prochain appel.

| Paramètre | Description |
|---|---|
| `motor` | `motorA` à `motorD` |
| `speed` | Puissance en %, de -100 (arrière) à +100 (avant). 0 = arrêt (commande `stop`) |

Erreurs : `CEVAR_ERR_PARAM` (moteur inconnu, ou vitesse hors plage : la vitesse est bornée à ±100 et le moteur tourne quand même), `CEVAR_ERR_NOT_FOUND` (aucun moteur sur ce port), `CEVAR_ERR_IO`, `CEVAR_ERR_NOT_INIT`.

## getMotorEncoder

```c
int getMotorEncoder(tMotor motor);
```

Position de l'encodeur, en degrés (360 impulsions par tour). Négative en sens inverse. Elle part de la valeur qu'avait l'encodeur au branchement : appeler `resetMotorEncoder()` pour partir de 0.

Renvoie 0 en cas d'erreur (`PARAM`, `NOT_FOUND`, `IO`, `NOT_INIT`).

## getMotorRPM

```c
int getMotorRPM(tMotor motor);
```

Vitesse de rotation mesurée, en tours par minute (valeur entière, tronquée). Négative en sens inverse, 0 à l'arrêt. Calcul : `vitesse (impulsions/s) × 60 / impulsions par tour`.

Renvoie 0 en cas d'erreur. Attention : 0 est aussi une valeur valide ; testez `cevar_getLastError()` si l'erreur compte.

## resetMotorEncoder

```c
void resetMotorEncoder(tMotor motor);
```

Remet l'encodeur à 0 (écriture de 0 dans l'attribut `position`). Le moteur n'est pas arrêté.

## Exemple

```c
#include <cevar/cevar.h>

int main(void)
{
    cevar_init();
    resetMotorEncoder(motorA);
    setMotorSpeed(motorA, 50);           /* avancer à 50 %            */
    /* ... attendre ... */
    int deg = getMotorEncoder(motorA);   /* degrés parcourus          */
    int rpm = getMotorRPM(motorA);       /* vitesse en tr/min         */
    setMotorSpeed(motorA, 0);            /* arrêt                     */
    cevar_exit();
    return 0;
}
```

Programme complet : `examples/moteurs.c`.

## Limites connues

- Le moteur **continue de tourner** si le programme se termine sans `setMotorSpeed(m, 0)` (comportement d'EV3Dev). L'arrêt automatique à la sortie n'est pas encore implémenté.
- Pas de rebranchement à chaud : un moteur branché après `cevar_init()` n'est pas détecté (relancer le programme).
- Le sens positif dépend du câblage et de la polarité du moteur.
- Les moteurs A et B ne sont pas synchronisés : le robot peut dévier légèrement en ligne droite.
- `getMotorRPM` et `getMotorEncoder` ne font pas de moyenne : ce sont des lectures instantanées.

## Tests

`tests/test_motor.c`, à lancer sur la brique (moteur sur A, port D vide) :

| Cas | Vérifie |
|---|---|
| 0 | avant `cevar_init()` : `NOT_INIT` pour les quatre fonctions |
| 1 | `+50` : encodeur qui augmente, RPM positif |
| 2 | RPM cohérent avec la variation de l'encodeur sur 1 s (tolérance 20 %, minimum 10 tr/min) |
| 3 | `-50` : encodeur qui diminue, RPM négatif |
| 4 | `0` : position stable, RPM nul |
| 5 | `resetMotorEncoder` : encodeur proche de 0 puis qui repart de 0 |
| 6 | `150` : `PARAM` signalé, moteur qui tourne (bornage à 100) |
| 7 | moteur invalide : `PARAM` |
| 8 | port D vide : `NOT_FOUND` (ignoré si un moteur y est branché) |

Les tolérances sont des valeurs de départ, à ajuster après les premières mesures.

## Correspondance ROBOTC

| ROBOTC | CEVAR | Remarque |
|---|---|---|
| `setMotorSpeed(motorA, 50)` | idem | puissance -100..100 |
| `getMotorEncoder(motorA)` | idem | degrés, renvoie `int` |
| `getMotorRPM(motorA)` | idem | tr/min, entier |
| `resetMotorEncoder(motorA)` | idem | n'arrête pas le moteur |

Comportements non vérifiés face à ROBOTC : valeur renvoyée en cas d'erreur, bornage des vitesses.
