/*
 * moteurs.c : exemple de programme utilisateur
 *
 * Fait avancer, reculer puis tourner sur place un robot a deux moteurs
 * (A = gauche, B = droite) en affichant l'encodeur et la vitesse.
 */
#include <stdio.h>
#include <unistd.h>

#include <cevar/cevar.h>

/* delay() arrivera a l'etape C : en attendant, une pause locale. */
static void pause_ms(unsigned ms) { usleep(ms * 1000u); }

static void afficher(const char *etape)
{
    int a = getMotorEncoder(motorA), ra = getMotorRPM(motorA);
    int b = getMotorEncoder(motorB), rb = getMotorRPM(motorB);

    printf("%-8s  A: %6d deg %4d tr/min   B: %6d deg %4d tr/min\n", etape, a, ra, b, rb);
}

int main(void)
{
    int i;

    cevar_init();
    resetMotorEncoder(motorA);
    resetMotorEncoder(motorB);

    printf("Avance pendant 2 s\n");
    setMotorSpeed(motorA, 60);
    setMotorSpeed(motorB, 60);
    for (i = 0; i < 4; i++) {
        pause_ms(500);
        afficher("avance");
    }

    setMotorSpeed(motorA, 0);
    setMotorSpeed(motorB, 0);
    pause_ms(500);
    afficher("arret");

    printf("Recule pendant 2 s\n");
    setMotorSpeed(motorA, -40);
    setMotorSpeed(motorB, -40);
    for (i = 0; i < 4; i++) {
        pause_ms(500);
        afficher("recule");
    }

    setMotorSpeed(motorA, 0);
    setMotorSpeed(motorB, 0);
    pause_ms(500);

    printf("Tourne sur place pendant 1 s\n");
    resetMotorEncoder(motorA);
    resetMotorEncoder(motorB);
    setMotorSpeed(motorA, 40);
    setMotorSpeed(motorB, -40);
    pause_ms(1000);
    afficher("tourne");

    setMotorSpeed(motorA, 0);
    setMotorSpeed(motorB, 0);

    cevar_exit();
    return 0;
}
